import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

void main() => runApp(new MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      title: 'Saikumarreddy Mulkalla APP!!',
      theme: new ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or press Run > Flutter Hot Reload in IntelliJ). Notice that the
        // counter didn't reset back to zero; the application is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: new ImageTile(),
    );
  }
}

List<StaggeredTile> _staggeredTiles = const <StaggeredTile>[
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
  const StaggeredTile.count(3,4),
];

List<Widget> _tiles = const <Widget>[
  const _ImageTile('https://source.unsplash.com/random/201x300'),
  const _ImageTile('https://source.unsplash.com/random/202x300'),
  const _ImageTile('https://media.giphy.com/media/5ndcoBdP3dbaVqpCzf/giphy.gif'),
  const _ImageTile('https://picsum.photos/201/300/?random'),
  const _ImageTile('https://media.giphy.com/media/Kc8MOlh4PuQXKhcYfk/giphy.gif'),
  const _ImageTile('https://source.unsplash.com/random/223x300'),
  const _ImageTile('https://media.giphy.com/media/UTwc22AJtMU3pV8jfe/giphy.gif'),
  const _ImageTile('https://picsum.photos/202/300/?random'),
  const _ImageTile('https://media.giphy.com/media/hTOKamJUc84ZxZpqYv/giphy.gif'),
  const _ImageTile('https://source.unsplash.com/random/203x300'),
  const _ImageTile('https://media.giphy.com/media/jn8uoA8ryhNOgkXAp1/giphy.gif'),
  const _ImageTile('https://picsum.photos/203/300/?random'),
  const _ImageTile('https://media.giphy.com/media/3osIrq5xX4DwVOcI2A/giphy.gif'),
  const _ImageTile('https://source.unsplash.com/random/204x300'),
  const _ImageTile('https://picsum.photos/204/300/?random'),
  const _ImageTile('https://media.giphy.com/media/Kzn74B9XXIFp1mk1Kd/giphy.gif'),
  const _ImageTile('https://picsum.photos/205/300/?random'),
  const _ImageTile('https://source.unsplash.com/random/205x300'),
  const _ImageTile('https://media.giphy.com/media/L3d8RsbHOeW1RHjh41/giphy.gif'),
  const _ImageTile('https://picsum.photos/206/300/?random'),
  const _ImageTile('https://media.giphy.com/media/l1J3zw3sgJ6Ye6I4E/giphy.gif'),
  const _ImageTile('https://source.unsplash.com/random/206x300'),
  const _ImageTile('https://source.unsplash.com/random/207x300'),
  const _ImageTile('https://picsum.photos/207/300/?random'),
  const _ImageTile('https://media.giphy.com/media/6C6AzTE7PV8vBrDwNu/giphy.gif'),
  const _ImageTile('https://picsum.photos/208/300/?random'),
  const _ImageTile('https://source.unsplash.com/random/208x300'),
  const _ImageTile('https://media.giphy.com/media/9Y3K9O78Y3W4pk6sgv/giphy.gif'),
  const _ImageTile('https://source.unsplash.com/random/209x300'),
  const _ImageTile('https://picsum.photos/209/300/?random'),
  const _ImageTile('https://media.giphy.com/media/jsTgk136sV71K/giphy.gif'),
  const _ImageTile('https://picsum.photos/210/300/?random'),
  const _ImageTile('https://media.giphy.com/media/Q8t3Mfn7TX7gD6l35d/giphy.gif'),
  const _ImageTile('https://source.unsplash.com/random/210x300'),
  const _ImageTile('https://source.unsplash.com/random/211x300'),
  const _ImageTile('https://media.giphy.com/media/YREwY96gNikqAvdF4D/giphy.gif'),
  const _ImageTile('https://picsum.photos/211/300/?random'),
  const _ImageTile('https://source.unsplash.com/random/212x300'),
  const _ImageTile('https://media.giphy.com/media/sXgNCQ6qvKVm8/giphy.gif'),
  const _ImageTile('https://picsum.photos/212/300/?random'),
  const _ImageTile('https://media.giphy.com/media/uAqYOiAIuenERmjPRM/giphy.gif'),
  const _ImageTile('https://source.unsplash.com/random/213x300'),
  const _ImageTile('https://source.unsplash.com/random/214x300'),
  const _ImageTile('https://picsum.photos/213/300/?random'),
  const _ImageTile('https://media.giphy.com/media/mCRJDo24UvJMA/giphy.gif'),
  const _ImageTile('https://picsum.photos/214/300/?random'),
  const _ImageTile('https://source.unsplash.com/random/215x300'),
  const _ImageTile('https://media.giphy.com/media/sHzXM26zxzT1yiPPje/giphy.gif'),
  const _ImageTile('https://picsum.photos/215/300/?random'),
  const _ImageTile('https://source.unsplash.com/random/216x300'),
  const _ImageTile('https://media.giphy.com/media/8y5JRwq9wZkhq/giphy.gif'),
  const _ImageTile('https://picsum.photos/216/300/?random'),
  const _ImageTile('https://media.giphy.com/media/Rjwnmsg3uPStVZQ45d/giphy.gif'),
  const _ImageTile('https://source.unsplash.com/random/217x300'),
  const _ImageTile('https://source.unsplash.com/random/222x300'),
  const _ImageTile('https://picsum.photos/217/300/?random'),
  const _ImageTile('https://media.giphy.com/media/3oriNVc5SDHOsWcCM8/giphy.gif'),
  const _ImageTile('https://picsum.photos/218/300/?random'),
  const _ImageTile('https://media.giphy.com/media/3o85xv55DJr0XGHwcM/giphy.gif'),
  const _ImageTile('https://picsum.photos/219/300/?random'),
  const _ImageTile('https://media.giphy.com/media/H4glhxCUA8aY3ivfym/giphy.gif'),
  const _ImageTile('https://source.unsplash.com/random/218x300'),
  const _ImageTile('https://media.giphy.com/media/e7GtKibZsDT6CmvBD3/giphy.gif'),
  const _ImageTile('https://picsum.photos/220/300/?random'),
  const _ImageTile('https://source.unsplash.com/random/221x300'),
  const _ImageTile('https://media.giphy.com/media/ie8M6ieLofDiqEGiYT/giphy.gif'),
  const _ImageTile('https://picsum.photos/221/300/?random'),
  const _ImageTile('https://source.unsplash.com/random/224x300'),
  const _ImageTile('https://media.giphy.com/media/AqWjaaWxTX0xa/giphy.gif'),
  const _ImageTile('https://source.unsplash.com/random/220x300'),
  const _ImageTile('https://picsum.photos/222/300/?random'),
  const _ImageTile('https://source.unsplash.com/random/225x300'),
  const _ImageTile('https://media.giphy.com/media/lP4mHceqfUhfUaPq95/giphy.gif'),
  const _ImageTile('https://source.unsplash.com/random/219x300'),
  const _ImageTile('https://picsum.photos/223/300/?random'),
  const _ImageTile('https://media.giphy.com/media/Up7H4poiaIhoENrnZk/giphy.gif'),
  const _ImageTile('https://picsum.photos/224/300/?random'),
  const _ImageTile('https://media.giphy.com/media/PieV1iOGo9STEZZDZB/giphy.gif'),
  const _ImageTile('https://picsum.photos/225/300/?random'),
  const _ImageTile('https://media.giphy.com/media/9liMa8E5te5kRVLn38/giphy.gif'),
];

class ImageTile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        backgroundColor: Colors.white,
          leading: IconButton(
            icon: Image.asset('assets/logo.jpg'),
            hoverColor: Colors.cyan,
            onPressed: () {
              print("Welcome to My App.. it's wonderfull meeting you");
            },
            iconSize: 50.0,
          ),
          title: new TextField(
            decoration: new InputDecoration(
              border: new OutlineInputBorder(
                borderSide: new BorderSide(width: 20),
                borderRadius: BorderRadius.all(Radius.circular(600)),
              ),
              hintText: "Search",
              prefixIcon: IconButton(
                icon: Icon(Icons.search),
                color: Colors.black,
                hoverColor: Colors.black54,
                onPressed: () {
                  print('Search Tab');
                },
              ),
              suffixIcon: IconButton(
                icon: Icon(Icons.mic),
                color: Colors.black,
                hoverColor: Colors.green,
                onPressed: () {
                  print('Ask Something');
                },
              ),
            ),
          ),
          actions: [
            Padding(
              padding: EdgeInsets.all(8.0),
              child: TextButton(
                child: Text('Home'),
                style: ButtonStyle(
                  foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.black),
                  overlayColor: MaterialStateProperty.all<Color>(Colors.orange),
                  textStyle: MaterialStateProperty.all(TextStyle(fontSize: 20)),
                  shape: MaterialStateProperty.all<OutlinedBorder>(
                          RoundedRectangleBorder(
                           borderRadius: BorderRadius.all(Radius.circular(20))
                          ),
                        ),
                ),
                onPressed: () {
                  print('HOME@@!!');
                },
              ),
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: TextButton(
                child: Text('Today'),
                style: ButtonStyle(
                  foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                  backgroundColor:MaterialStateProperty.all<Color>(Colors.black),
                  overlayColor: MaterialStateProperty.all<Color>(Colors.red),
                  textStyle: MaterialStateProperty.all(TextStyle(fontSize: 20)),
                  shape: MaterialStateProperty.all<OutlinedBorder>(
                          RoundedRectangleBorder(
                           borderRadius: BorderRadius.all(Radius.circular(20)),
                          ),
                        ),
                ),
                onPressed: () {
                  print("Today's collection");
                },
              ),
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: TextButton(
                child: Text('For You'),
                style: ButtonStyle(
                  foregroundColor:MaterialStateProperty.all<Color>(Colors.white),
                  backgroundColor:MaterialStateProperty.all<Color>(Colors.black),
                  overlayColor: MaterialStateProperty.all<Color>(Colors.pink),
                  textStyle: MaterialStateProperty.all(TextStyle(fontSize: 20)),
                  shape: MaterialStateProperty.all<OutlinedBorder>(
                          RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                          ),
                        ),
                ),
                onPressed: () {
                  print('Specially for you@@');
                },
              ),
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: IconButton(
                icon: Icon(Icons.notifications),
                color: Colors.black,
                hoverColor: Colors.green,
                iconSize: 30.0,
                onPressed: () {
                  print('your notifications');
                },
              ),
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: IconButton(
                icon: Icon(Icons.message),
                color: Colors.black,
                hoverColor: Colors.blue,
                iconSize: 30.0,
                onPressed: () {
                  print('your messages');
                },
              ),
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: IconButton(
                icon: Icon(Icons.account_circle_outlined),
                color: Colors.black,
                hoverColor: Colors.deepPurple,
                iconSize: 30.0,
                onPressed: () {
                  print('you are logged in with gmail');
                },
              ),
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: IconButton(
                icon: Icon(Icons.expand_more_sharp),
                color: Colors.black,
                hoverColor: Colors.cyanAccent,
                iconSize: 30.0,
                onPressed: () {print('more options');},
              ),
            ),
          ],
        ),
        body:new Padding(
          padding: const EdgeInsets.only(top: 12.0),
          child: new StaggeredGridView.count(
            crossAxisCount: 12,
            staggeredTiles: _staggeredTiles,
            children: _tiles,
            mainAxisSpacing: 6.0,
            crossAxisSpacing: 6.0,
          ),
        ),
        floatingActionButton: Stack(
          children: [
            Positioned(
              bottom: 0.0,
              right: 0.0,
              child: FloatingActionButton(
                child: Icon(
                  Icons.help_outline_sharp,
                  color: Colors.black,
                  size: 50.0,
                ),
                backgroundColor: Colors.white,
                foregroundColor: Colors.black,
                hoverColor: Colors.amberAccent,
                onPressed: () {print('Visit Help Center');},
              ),
            ),
            Positioned(
              bottom: 65.0,
              right: 0.0,
              child: FloatingActionButton(
                child: Icon(
                  Icons.add_outlined,
                  color: Colors.black,
                  size: 50.0,
                ),
                backgroundColor: Colors.white,
                foregroundColor: Colors.black,
                hoverColor: Colors.purple,
                onPressed: () {print('willing to add something');}, 
              ),
            ),
          ],
        ),
    );
  }
}

class _ImageTile extends StatefulWidget {
  const _ImageTile(this.gridImage);

  final gridImage;

  @override
  __ImageTileState createState() => __ImageTileState();
}

class __ImageTileState extends State<_ImageTile> {
  bool isHoveringActive = false;
  @override
  Widget build(BuildContext context) {
    return new Card(
      color: const Color(0x00000000),
      elevation: 3.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(20.0)),
      ),
      child: new InkResponse(
        onTap: () {
          setState((){
            isHoveringActive = true;
          });
        },
        onHover: (hover){
          print('isHovering');
          setState(() {
            isHoveringActive = hover;
          });
        },
        child: isHoveringActive ? Container(
          child: Stack(
            children: [
              Opacity(
                opacity: 0.6,
                child: Container(
                  decoration: new BoxDecoration(
                    image: new DecorationImage(
                      image: new NetworkImage(widget.gridImage),
                      fit: BoxFit.cover,
                    ),
                    borderRadius: new BorderRadius.all(const Radius.circular(20.0)),
                  ),
                ),
              ),
              Positioned(
                top: 20.0,
                right: 15.0,
                child: Container(
                  child: TextButton(
                    child: Text('SAVE'),
                    style: ButtonStyle(
                      foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.red),
                      overlayColor: MaterialStateProperty.all<Color>(Colors.blue),
                      textStyle: MaterialStateProperty.all(TextStyle(fontSize: 20)),
                      shape: MaterialStateProperty.all<OutlinedBorder>(
                          RoundedRectangleBorder(
                           borderRadius: BorderRadius.all(Radius.circular(20))
                          ),
                      ),
                    ),
                    onPressed: () {
                      print('Saved to Device');
                    },
                  )
                ),
              ),
              Positioned(
                bottom: 20.0,
                right: 0.0,
                child: Container(
                  child: ElevatedButton(
                    child: Icon(
                      Icons.more_horiz_sharp,
                      color: Colors.black,
                    ),
                    style: ButtonStyle(
                      foregroundColor: MaterialStateProperty.all<Color>(Colors.black),
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
                      overlayColor: MaterialStateProperty.all<Color>(Colors.red),
                      shape: MaterialStateProperty.all<OutlinedBorder>(CircleBorder(side: BorderSide.none)),
                    ),
                    onPressed: () {print('more options');},
                  ),
                ),
              ),
              Positioned(
                bottom: 20.0,
                right: 40.0,
                child: Container(
                  child: ElevatedButton(
                    child: Icon(
                      Icons.ios_share,
                      color: Colors.black,
                    ),
                    style: ButtonStyle(
                      foregroundColor: MaterialStateProperty.all<Color>(Colors.black),
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
                      overlayColor: MaterialStateProperty.all<Color>(Colors.deepOrangeAccent),
                      shape: MaterialStateProperty.all<OutlinedBorder>(CircleBorder(side: BorderSide.none)),
                    ),
                    onPressed: () {print('Share on Social Media!!');},
                  ),
                ),
              ),
              Positioned(
                bottom: 20.0,
                left: 0.0,
                child: Container(
                  child: ElevatedButton.icon(
                    label: Text(widget.gridImage.substring(0,25)+'....'),
                    icon: Icon(
                      Icons.call_made_sharp,
                      color: Colors.black,
                    ),
                    style: ButtonStyle(
                      foregroundColor: MaterialStateProperty.all<Color>(Colors.black),
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
                      overlayColor: MaterialStateProperty.all<Color>(Colors.indigo),
                      shape: MaterialStateProperty.all<OutlinedBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(20.0)),
                        ),
                      ), 
                    ),
                    onPressed: () {print('navigating to original page');},
                  ),
                ),
              ),
            ],
          ),
        ):Container(
                  decoration: new BoxDecoration(
                    image: new DecorationImage(
                      image: new NetworkImage(widget.gridImage),
                      fit: BoxFit.cover,
                    ),
                    borderRadius: new BorderRadius.all(const Radius.circular(20.0)),
                  ),
                ),
      ),
    );
  }
}



